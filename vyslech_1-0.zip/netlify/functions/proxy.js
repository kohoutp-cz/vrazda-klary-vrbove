const { Configuration, OpenAIApi } = require("openai");

exports.handler = async function(event) {
  const body = JSON.parse(event.body);
  const configuration = new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
  });
  const openai = new OpenAIApi(configuration);

  const messages = [
    {
      role: "system",
      content: "Jsi detektiv s 20 lety praxe. Máš před sebou podezřelého ve věci vraždy Kláry Vrbové. Hraj výslech. Začni klidně, ale tlač na rozpory a konec po 10 minutách vyhodnoť: obviněn, propuštěn nebo sledován.",
    },
    {
      role: "user",
      content: body.message
    }
  ];

  try {
    const completion = await openai.createChatCompletion({
      model: "gpt-4",
      messages: messages
    });
    return {
      statusCode: 200,
      body: JSON.stringify({ reply: completion.data.choices[0].message.content })
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
